import type { DebuggerPlugin } from '../../core/types';
export declare function createStateInspectorPlugin(): DebuggerPlugin;
//# sourceMappingURL=StateInspectorPlugin.d.ts.map