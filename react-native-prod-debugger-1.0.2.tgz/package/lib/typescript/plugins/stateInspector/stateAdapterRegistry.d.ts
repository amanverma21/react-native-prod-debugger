/**
 * State Adapter Registry — Allows consumers to register their state stores.
 *
 * Supports Redux, Zustand, MobX, or any custom state store via a simple adapter interface.
 */
export interface StateAdapter {
    /** Adapter name (e.g., "Redux", "Zustand - userStore"). */
    name: string;
    /** Get the current state snapshot. */
    getState: () => unknown;
    /** Subscribe to state changes. Returns unsubscribe function. */
    subscribe?: (listener: () => void) => () => void;
}
type AdapterListener = () => void;
declare class StateAdapterRegistryClass {
    private adapters;
    private listeners;
    /** Register a state adapter. */
    set(id: string, adapter: StateAdapter): void;
    /** Remove a state adapter. */
    remove(id: string): void;
    /** Get all registered adapters. */
    getAll(): Map<string, StateAdapter>;
    /** Subscribe to adapter changes. */
    subscribe(listener: AdapterListener): () => void;
    private notify;
}
export declare const stateAdapterRegistry: StateAdapterRegistryClass;
/** Register a state store adapter. */
export declare function setStateAdapter(id: string, adapter: StateAdapter): void;
/** Remove a state store adapter. */
export declare function removeStateAdapter(id: string): void;
export {};
//# sourceMappingURL=stateAdapterRegistry.d.ts.map