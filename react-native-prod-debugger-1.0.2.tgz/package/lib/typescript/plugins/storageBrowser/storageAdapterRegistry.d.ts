import type { StorageAdapter } from '../../core/types';
type Listener = () => void;
declare class StorageAdapterRegistryClass {
    private adapters;
    private listeners;
    set(id: string, adapter: StorageAdapter): void;
    remove(id: string): void;
    getAll(): Map<string, StorageAdapter>;
    subscribe(listener: Listener): () => void;
    private notify;
}
export declare const storageAdapterRegistry: StorageAdapterRegistryClass;
export declare function setStorageAdapter(id: string, adapter: StorageAdapter): void;
export declare function removeStorageAdapter(id: string): void;
export {};
//# sourceMappingURL=storageAdapterRegistry.d.ts.map