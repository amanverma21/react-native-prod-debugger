import type { DebuggerPlugin } from '../../core/types';
export declare function createStorageBrowserPlugin(): DebuggerPlugin;
//# sourceMappingURL=StorageBrowserPlugin.d.ts.map