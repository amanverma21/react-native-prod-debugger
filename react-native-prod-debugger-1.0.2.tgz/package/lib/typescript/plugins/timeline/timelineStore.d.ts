import type { TimelineEvent } from '../../core/types';
type TimelineListener = (events: TimelineEvent[]) => void;
/**
 * TimelineStore — Global event logger for tracking app lifecycle events.
 *
 * Records events with category, timestamp, and optional data.
 * Useful for tracking user flows, state transitions, and debugging sequences.
 */
declare class TimelineStoreClass {
    private events;
    private listeners;
    private maxEvents;
    /** Log a timeline event. */
    log(category: TimelineEvent['category'], title: string, data?: unknown): void;
    getAll(): TimelineEvent[];
    clear(): void;
    subscribe(listener: TimelineListener): () => void;
    private notify;
}
export declare const timelineStore: TimelineStoreClass;
/** Log a timeline event. */
export declare function logTimelineEvent(category: TimelineEvent['category'], title: string, data?: unknown): void;
export {};
//# sourceMappingURL=timelineStore.d.ts.map