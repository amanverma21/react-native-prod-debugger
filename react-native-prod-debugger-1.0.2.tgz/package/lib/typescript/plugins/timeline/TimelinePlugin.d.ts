import type { DebuggerPlugin } from '../../core/types';
export declare function createTimelinePlugin(): DebuggerPlugin;
//# sourceMappingURL=TimelinePlugin.d.ts.map