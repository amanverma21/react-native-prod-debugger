import type { DebuggerPlugin } from '../../core/types';
export declare function createFeatureFlagsPlugin(): DebuggerPlugin;
//# sourceMappingURL=FeatureFlagsPlugin.d.ts.map