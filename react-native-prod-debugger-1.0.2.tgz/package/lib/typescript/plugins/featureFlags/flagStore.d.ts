import type { FeatureFlag } from '../../core/types';
type FlagListener = (flags: FeatureFlag[]) => void;
/**
 * Feature Flag Store — In-memory registry for feature flags.
 *
 * Flags can be registered by the consumer app and toggled at runtime
 * via the debugger overlay. Overrides persist in-memory (optionally in AsyncStorage).
 */
declare class FlagStoreClass {
    private flags;
    private listeners;
    private changeCallbacks;
    /** Register a feature flag. */
    register(flag: Omit<FeatureFlag, 'currentValue'> & {
        currentValue?: FeatureFlag['currentValue'];
    }): void;
    /** Get a flag value. Returns the overridden value if set, otherwise the default. */
    get(key: string): FeatureFlag['currentValue'] | undefined;
    /** Get a flag definition. */
    getFlag(key: string): FeatureFlag | undefined;
    /** Get all flags. */
    getAll(): FeatureFlag[];
    /** Override a flag value. */
    override(key: string, value: FeatureFlag['currentValue']): void;
    /** Reset a single flag to its default value. */
    reset(key: string): void;
    /** Reset all flags to defaults. */
    resetAll(): void;
    /** Register a callback when a specific flag changes. */
    onChange(key: string, callback: (value: FeatureFlag['currentValue']) => void): () => void;
    /** Subscribe to all flag changes. */
    subscribe(listener: FlagListener): () => void;
    private notify;
}
declare const flagStore: FlagStoreClass;
/** Register a feature flag. */
export declare function registerFlag(flag: Omit<FeatureFlag, 'currentValue'> & {
    currentValue?: FeatureFlag['currentValue'];
}): void;
/** Reset all flag overrides. */
export declare function resetFlags(): void;
/** Get a flag's current value. */
export declare function getFlag(key: string): FeatureFlag['currentValue'] | undefined;
export { flagStore };
//# sourceMappingURL=flagStore.d.ts.map