import type { CustomAction } from '../../core/types';
type ActionListener = (actions: CustomAction[]) => void;
declare class ActionStoreClass {
    private actions;
    private listeners;
    register(action: CustomAction): void;
    remove(id: string): void;
    getAll(): CustomAction[];
    subscribe(listener: ActionListener): () => void;
    private notify;
}
export declare const actionStore: ActionStoreClass;
export declare function registerAction(action: CustomAction): void;
export declare function removeAction(id: string): void;
export {};
//# sourceMappingURL=actionStore.d.ts.map