import type { DebuggerPlugin } from '../../core/types';
export declare function createCustomActionsPlugin(): DebuggerPlugin;
//# sourceMappingURL=CustomActionsPlugin.d.ts.map