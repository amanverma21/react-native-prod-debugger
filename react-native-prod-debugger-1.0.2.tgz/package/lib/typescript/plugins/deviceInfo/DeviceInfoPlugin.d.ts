import type { DebuggerPlugin } from '../../core/types';
export declare function createDeviceInfoPlugin(): DebuggerPlugin;
//# sourceMappingURL=DeviceInfoPlugin.d.ts.map