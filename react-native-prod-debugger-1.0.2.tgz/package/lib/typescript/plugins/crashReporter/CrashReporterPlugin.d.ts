import type { DebuggerPlugin } from '../../core/types';
export declare function createCrashReporterPlugin(): DebuggerPlugin;
//# sourceMappingURL=CrashReporterPlugin.d.ts.map