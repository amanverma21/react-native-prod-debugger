import type { DebuggerPlugin } from '../../core/types';
export declare function createDeepLinkTesterPlugin(): DebuggerPlugin;
//# sourceMappingURL=DeepLinkTesterPlugin.d.ts.map