import type { DebuggerPlugin } from '../../core/types';
export declare function createPerformanceMonitorPlugin(): DebuggerPlugin;
//# sourceMappingURL=PerformanceMonitorPlugin.d.ts.map