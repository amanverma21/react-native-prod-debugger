import type { NetworkRequest } from '../../core/types';
type NetworkListener = (requests: NetworkRequest[]) => void;
/**
 * NetworkInterceptor — Intercepts XMLHttpRequest and fetch to capture network traffic.
 *
 * Uses monkey-patching to wrap the global XHR and fetch implementations.
 * Stores request/response data in an in-memory ring buffer.
 * Thread-safe listener management for UI updates.
 */
declare class NetworkInterceptorClass {
    private requests;
    private listeners;
    private maxRequests;
    private isActive;
    private originalXHROpen;
    private originalXHRSend;
    private originalXHRSetHeader;
    private originalFetch;
    /** Start intercepting network requests. */
    start(maxRequests?: number, forceEnable?: boolean): void;
    /** Stop intercepting and restore original implementations. */
    stop(): void;
    /** Subscribe to request changes. Returns unsubscribe function. */
    subscribe(listener: NetworkListener): () => void;
    /** Get all captured requests. */
    getAll(): NetworkRequest[];
    /** Clear all captured requests. */
    clear(): void;
    /** Check if the interceptor is active. */
    get active(): boolean;
    private interceptXHR;
    private restoreXHR;
    private interceptFetch;
    private restoreFetch;
    private addRequest;
    private updateRequest;
    private notify;
}
/** Singleton network interceptor instance. */
export declare const NetworkInterceptor: NetworkInterceptorClass;
export {};
//# sourceMappingURL=NetworkInterceptor.d.ts.map