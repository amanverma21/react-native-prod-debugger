import type { DebuggerPlugin } from '../../core/types';
export declare function createNetworkInspectorPlugin(): DebuggerPlugin;
//# sourceMappingURL=NetworkInspectorPlugin.d.ts.map