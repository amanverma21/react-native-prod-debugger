import type { RemoteConfigProvider } from '../../core/types';
type Listener = () => void;
declare class RemoteConfigStoreClass {
    private provider;
    private listeners;
    /** Set the remote config provider. */
    set(provider: RemoteConfigProvider): void;
    /** Get the current provider. */
    get(): RemoteConfigProvider | null;
    /** Remove the provider. */
    remove(): void;
    /** Subscribe to provider changes. */
    subscribe(listener: Listener): () => void;
    private notify;
}
export declare const remoteConfigStore: RemoteConfigStoreClass;
/** Set the remote config provider (e.g., Firebase). */
export declare function setRemoteConfigProvider(provider: RemoteConfigProvider): void;
export {};
//# sourceMappingURL=remoteConfigStore.d.ts.map