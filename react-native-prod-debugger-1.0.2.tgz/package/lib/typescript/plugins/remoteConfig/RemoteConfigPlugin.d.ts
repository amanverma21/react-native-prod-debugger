import type { DebuggerPlugin } from '../../core/types';
export declare function createRemoteConfigPlugin(): DebuggerPlugin;
//# sourceMappingURL=RemoteConfigPlugin.d.ts.map