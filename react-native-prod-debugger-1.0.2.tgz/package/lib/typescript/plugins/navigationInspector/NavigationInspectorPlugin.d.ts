import type { DebuggerPlugin } from '../../core/types';
export declare function createNavigationInspectorPlugin(): DebuggerPlugin;
//# sourceMappingURL=NavigationInspectorPlugin.d.ts.map