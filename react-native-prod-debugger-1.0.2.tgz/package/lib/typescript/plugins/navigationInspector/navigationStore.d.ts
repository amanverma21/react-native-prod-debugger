type Listener = () => void;
declare class NavigationStoreClass {
    private ref;
    private history;
    private listeners;
    private maxHistory;
    setRef(ref: {
        current: unknown;
    }): void;
    getRef(): unknown;
    addHistoryEntry(name: string, params?: Record<string, unknown>): void;
    getHistory(): {
        name: string;
        params?: Record<string, unknown>;
        timestamp: number;
    }[];
    getState(): unknown;
    getCurrentRoute(): {
        name: string;
        params?: Record<string, unknown>;
    } | null;
    subscribe(listener: Listener): () => void;
    private notify;
}
export declare const navigationStore: NavigationStoreClass;
export declare function setNavigationRef(ref: {
    current: unknown;
}): void;
export {};
//# sourceMappingURL=navigationStore.d.ts.map