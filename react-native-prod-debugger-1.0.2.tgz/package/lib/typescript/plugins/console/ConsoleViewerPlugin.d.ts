import type { DebuggerPlugin } from '../../core/types';
export declare function createConsoleViewerPlugin(): DebuggerPlugin;
//# sourceMappingURL=ConsoleViewerPlugin.d.ts.map