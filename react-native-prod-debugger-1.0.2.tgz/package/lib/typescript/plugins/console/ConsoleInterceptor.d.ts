import type { ConsoleEntry } from '../../core/types';
type ConsoleListener = (entries: ConsoleEntry[]) => void;
/**
 * ConsoleInterceptor — Captures console.log/warn/error/info/debug calls.
 *
 * Wraps the global console methods and stores entries in a ring buffer.
 * Original console behavior is preserved — messages still appear in the developer console.
 */
declare class ConsoleInterceptorClass {
    private entries;
    private listeners;
    private maxEntries;
    private isActive;
    private originals;
    /** Start intercepting console calls. */
    start(maxEntries?: number): void;
    /** Stop intercepting and restore original console. */
    stop(): void;
    /** Subscribe to entry changes. Returns unsubscribe function. */
    subscribe(listener: ConsoleListener): () => void;
    /** Get all entries. */
    getAll(): ConsoleEntry[];
    /** Clear all entries. */
    clear(): void;
    get active(): boolean;
    private addEntry;
    private notify;
}
/** Singleton console interceptor instance. */
export declare const ConsoleInterceptor: ConsoleInterceptorClass;
export {};
//# sourceMappingURL=ConsoleInterceptor.d.ts.map