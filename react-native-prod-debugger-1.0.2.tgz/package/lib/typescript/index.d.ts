/**
 * react-native-prod-debugger
 *
 * A comprehensive, in-app debugging toolkit for React Native
 * that works in production builds.
 *
 * @packageDocumentation
 */
export { DebuggerProvider } from './core/DebuggerProvider';
export { useDebugger } from './core/useDebugger';
export { PluginRegistry, registerPlugin, unregisterPlugin } from './core/PluginRegistry';
export type { DebuggerConfig, DebuggerPlugin, DebuggerTheme, NetworkRequest, ConsoleEntry, ConsoleLevel, FeatureFlag, FlagType, RemoteConfigProvider, RemoteConfigValue, StorageAdapter, TimelineEvent, EventCategory, CrashEntry, CustomAction, PluginComponentProps, } from './core/types';
export { NetworkInterceptor } from './plugins/network/NetworkInterceptor';
export { ConsoleInterceptor } from './plugins/console/ConsoleInterceptor';
export { registerFlag, resetFlags, getFlag } from './plugins/featureFlags/flagStore';
export { setStateAdapter, removeStateAdapter } from './plugins/stateInspector/stateAdapterRegistry';
export type { StateAdapter } from './plugins/stateInspector/stateAdapterRegistry';
export { setRemoteConfigProvider } from './plugins/remoteConfig/remoteConfigStore';
export { setStorageAdapter, removeStorageAdapter, } from './plugins/storageBrowser/storageAdapterRegistry';
export { setNavigationRef } from './plugins/navigationInspector/navigationStore';
export { registerAction, removeAction } from './plugins/customActions/actionStore';
export { logTimelineEvent } from './plugins/timeline/timelineStore';
//# sourceMappingURL=index.d.ts.map