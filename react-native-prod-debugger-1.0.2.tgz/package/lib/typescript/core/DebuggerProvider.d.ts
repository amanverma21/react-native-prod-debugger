import React from 'react';
import type { DebuggerConfig, DebuggerContextValue, ChildrenProp } from './types';
export declare const DebuggerContext: React.Context<DebuggerContextValue | null>;
interface DebuggerProviderProps extends ChildrenProp {
    config?: DebuggerConfig;
}
/**
 * DebuggerProvider — Wrap your app with this to enable the production debugger.
 *
 * @example
 * ```tsx
 * import { DebuggerProvider } from 'react-native-prod-debugger';
 *
 * export default function App() {
 *   return (
 *     <DebuggerProvider config={{ appVersion: '1.2.3' }}>
 *       <YourApp />
 *     </DebuggerProvider>
 *   );
 * }
 * ```
 */
export declare const DebuggerProvider: React.FC<DebuggerProviderProps>;
export {};
//# sourceMappingURL=DebuggerProvider.d.ts.map