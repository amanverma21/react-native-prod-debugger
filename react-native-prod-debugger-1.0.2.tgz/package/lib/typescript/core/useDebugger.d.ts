import type { DebuggerContextValue } from './types';
/**
 * Hook to access the debugger context.
 *
 * @example
 * ```tsx
 * const { show, hide, toggle, isVisible } = useDebugger();
 *
 * // Programmatically open the debugger
 * show();
 * ```
 */
export declare function useDebugger(): DebuggerContextValue;
//# sourceMappingURL=useDebugger.d.ts.map