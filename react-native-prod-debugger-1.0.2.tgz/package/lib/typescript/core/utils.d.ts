/** Generate a unique ID (collision-safe for debugging purposes). */
export declare function generateId(): string;
/** Format bytes into a human-readable string. */
export declare function formatBytes(bytes: number | undefined): string;
/** Format milliseconds into a readable duration. */
export declare function formatDuration(ms: number | undefined): string;
/** Format a UNIX timestamp into a local time string (HH:MM:SS.mmm). */
export declare function formatTimestamp(ts: number): string;
/** Format a relative time ago (e.g., "2s ago", "5m ago"). */
export declare function formatTimeAgo(ts: number): string;
/** Truncate a string with ellipsis if it exceeds maxLength. */
export declare function truncate(str: string, maxLength?: number): string;
/** Safely serialize any value to a JSON string with pretty printing. */
export declare function safeStringify(value: unknown, indent?: number): string;
/** Safely parse a JSON string, returning null on failure. */
export declare function safeParse(str: string): unknown | null;
/** Copy text to the device clipboard. */
export declare function copyToClipboard(text: string): Promise<void>;
/** Share text via the native share sheet. */
export declare function shareText(text: string, title?: string): Promise<void>;
/** Get the HTTP status color based on the status code. */
export declare function getStatusColor(status: number | undefined): string;
/** Get the HTTP method color. */
export declare function getMethodColor(method: string): string;
/** Get a console level color. */
export declare function getLevelColor(level: string): string;
/**
 * Extract GraphQL operation name and type from request body.
 * Returns `null` if it's not a GraphQL request.
 */
export declare function extractGraphQLInfo(body: string | undefined): {
    operation: string;
    type: string;
} | null;
/**
 * Convert a network request to a cURL command string.
 */
export declare function toCurl(request: {
    method: string;
    url: string;
    requestHeaders?: Record<string, string>;
    requestBody?: string;
}): string;
/** Debounce function calls. */
export declare function debounce<T extends (...args: unknown[]) => void>(fn: T, delay: number): (...args: Parameters<T>) => void;
//# sourceMappingURL=utils.d.ts.map