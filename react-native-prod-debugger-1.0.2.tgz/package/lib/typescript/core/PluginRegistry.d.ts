import type { DebuggerPlugin } from './types';
/**
 * PluginRegistry — Central registry for all debugger plugins.
 *
 * Plugins are stored in a static array and sorted by their `order` property.
 * Built-in plugins are registered automatically by DebuggerProvider.
 * Custom plugins can be registered by consumers at any time.
 */
declare class PluginRegistryClass {
    private plugins;
    private listeners;
    /** Register a plugin. Replaces existing plugin with the same ID. */
    register(plugin: DebuggerPlugin): void;
    /** Unregister a plugin by ID. */
    unregister(id: string): void;
    /** Get all registered plugins, sorted by order. */
    getAll(): DebuggerPlugin[];
    /** Get a plugin by ID. */
    get(id: string): DebuggerPlugin | undefined;
    /** Check if a plugin is registered. */
    has(id: string): boolean;
    /** Get the count of registered plugins. */
    get count(): number;
    /** Subscribe to registry changes. Returns unsubscribe function. */
    subscribe(listener: () => void): () => void;
    /** Initialize all plugins (called by DebuggerProvider on mount). */
    initAll(): void;
    /** Destroy all plugins (called by DebuggerProvider on unmount). */
    destroyAll(): void;
    /** Clear all plugins from the registry. */
    clear(): void;
    private notify;
}
/** Singleton plugin registry instance. */
export declare const PluginRegistry: PluginRegistryClass;
/** Register a custom plugin. Convenience function. */
export declare function registerPlugin(plugin: DebuggerPlugin): void;
/** Unregister a plugin by ID. Convenience function. */
export declare function unregisterPlugin(id: string): void;
export {};
//# sourceMappingURL=PluginRegistry.d.ts.map