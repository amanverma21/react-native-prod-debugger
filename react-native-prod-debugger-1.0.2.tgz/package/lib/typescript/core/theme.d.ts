import type { DebuggerTheme } from './types';
/**
 * Default dark theme — designed for optimal readability on top of any app UI.
 * High-contrast text, muted backgrounds with alpha transparency for the overlay.
 */
export declare const darkTheme: DebuggerTheme;
/**
 * Merge user theme overrides with the default dark theme.
 */
export declare function createTheme(overrides?: Partial<DebuggerTheme>): DebuggerTheme;
//# sourceMappingURL=theme.d.ts.map