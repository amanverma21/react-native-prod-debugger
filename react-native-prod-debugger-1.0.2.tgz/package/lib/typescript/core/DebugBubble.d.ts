import React from 'react';
import type { DebuggerTheme } from './types';
interface DebugBubbleProps {
    onPress: () => void;
    theme: DebuggerTheme;
    size?: number;
    initialPosition?: {
        x: number;
        y: number;
    };
}
/**
 * DebugBubble — A floating, draggable FAB that opens the debug overlay.
 *
 * - Fully draggable via PanResponder
 * - Snaps to the nearest screen edge on release
 * - Pulses subtly to indicate interactivity
 * - Renders above all other content
 */
export declare const DebugBubble: React.FC<DebugBubbleProps>;
export {};
//# sourceMappingURL=DebugBubble.d.ts.map