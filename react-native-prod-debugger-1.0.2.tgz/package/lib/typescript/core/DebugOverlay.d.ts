import React from 'react';
import type { DebuggerPlugin, DebuggerTheme } from './types';
interface DebugOverlayProps {
    plugins: DebuggerPlugin[];
    theme: DebuggerTheme;
    onClose: () => void;
}
/**
 * DebugOverlay — Full-screen modal with tab navigation for plugins.
 *
 * - Slide-up animation on open
 * - Scrollable tab bar at the top
 * - Each tab renders a plugin's component
 * - Close button in the header
 */
export declare const DebugOverlay: React.FC<DebugOverlayProps>;
export {};
//# sourceMappingURL=DebugOverlay.d.ts.map